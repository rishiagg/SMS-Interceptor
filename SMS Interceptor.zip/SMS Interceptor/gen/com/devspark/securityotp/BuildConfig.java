/** Automatically generated file. DO NOT MODIFY */
package com.devspark.securityotp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}